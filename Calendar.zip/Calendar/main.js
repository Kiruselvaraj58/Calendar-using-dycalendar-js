dycalendar.draw({
    target: '#dycalendar',
    type: 'month',
    highlighttoday:true,
    prevnextbutton: "show"
});